import './App.css';
import {FichaProducto} from './components/fichaProducto/fichaProducto';
import { ListadoProductos } from './components/listadoProductos/listadoProductos';


function App() {
  return (
    <>
    <ListadoProductos>
    </ListadoProductos>   

     
    <FichaProducto identificador="59">
    </FichaProducto>
    
    
    </>
    
  );
}

export default App;
